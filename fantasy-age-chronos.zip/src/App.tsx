import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Clock, Calendar, Star, Zap, Heart } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AgeDetails {
  years: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

const QUOTES = [
  "The stars are aligning for your next chapter.",
  "Your aura is glowing today, bestie.",
  "Manifesting a legendary year for you.",
  "Main character energy incoming...",
  "The universe is gatekeeping your best days yet.",
  "Stay iconic, the world needs your vibe.",
  "You're not just aging, you're leveling up.",
  "Time is a social construct, but your drip is real."
];

export default function App() {
  const [dob, setDob] = useState<string>('');
  const [age, setAge] = useState<AgeDetails | null>(null);
  const [isBirthday, setIsBirthday] = useState(false);
  const [quote, setQuote] = useState('');
  const [isFuture, setIsFuture] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setQuote(QUOTES[Math.floor(Math.random() * QUOTES.length)]);
  }, []);

  const calculateAge = (birthDate: Date) => {
    const now = new Date();
    const diff = now.getTime() - birthDate.getTime();

    if (diff < 0) return null;

    const years = now.getFullYear() - birthDate.getFullYear();
    const isBirthdayToday = 
      now.getMonth() === birthDate.getMonth() && 
      now.getDate() === birthDate.getDate();

    // Total calculations
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    return {
      years: now.getMonth() < birthDate.getMonth() || (now.getMonth() === birthDate.getMonth() && now.getDate() < birthDate.getDate()) 
        ? years - 1 
        : years,
      days,
      hours,
      minutes,
      seconds
    };
  };

  useEffect(() => {
    if (dob) {
      const birthDate = new Date(dob);
      const update = () => {
        const now = new Date();
        const isFutureDate = birthDate.getTime() > now.getTime();
        setIsFuture(isFutureDate);

        if (isFutureDate) {
          setAge(null);
          return;
        }

        const newAge = calculateAge(birthDate);
        setAge(newAge);

        const isBday = now.getMonth() === birthDate.getMonth() && now.getDate() === birthDate.getDate();
        setIsBirthday(isBday);
        
        if (isBday && !isBirthday) {
          confetti({
            particleCount: 150,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#8B5CF6', '#EC4899', '#22D3EE']
          });
        }
      };

      update();
      timerRef.current = setInterval(update, 1000);
    } else {
      setAge(null);
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [dob]);

  return (
    <div className="min-h-screen fantasy-gradient flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-fantasy-purple/20 blur-[120px] rounded-full" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-fantasy-pink/20 blur-[120px] rounded-full" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="z-10 w-full max-w-2xl"
      >
        <header className="text-center mb-12">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 5, repeat: Infinity }}
            className="inline-block mb-4"
          >
            <Sparkles className="w-12 h-12 text-fantasy-cyan" />
          </motion.div>
          <h1 className="text-5xl md:text-7xl font-display font-bold mb-4 tracking-tighter neon-text">
            FANTASY <span className="text-fantasy-purple">WORLD</span>
          </h1>
          <p className="text-gray-400 text-lg md:text-xl font-light">
            Enter your origin date to reveal your cosmic existence.
          </p>
        </header>

        <div className="glass-card p-8 md:p-12 mb-8">
          <div className="flex flex-col space-y-6">
            <label className="text-sm uppercase tracking-widest text-gray-500 font-semibold flex items-center gap-2">
              <Calendar className="w-4 h-4" /> Date of Birth
            </label>
            <input
              type="date"
              value={dob}
              onChange={(e) => setDob(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-6 py-4 text-2xl focus:outline-none focus:ring-2 focus:ring-fantasy-purple transition-all cursor-pointer"
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          {age ? (
            <motion.div
              key="results"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {[
                  { label: 'Years', value: age.years, icon: Star },
                  { label: 'Days', value: age.days.toLocaleString(), icon: Clock },
                  { label: 'Hours', value: age.hours.toLocaleString(), icon: Zap },
                  { label: 'Minutes', value: age.minutes.toLocaleString(), icon: Heart },
                  { label: 'Seconds', value: age.seconds.toLocaleString(), icon: Sparkles },
                ].map((item, i) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="glass-card p-4 text-center group hover:bg-white/10 transition-colors"
                  >
                    <item.icon className="w-5 h-5 mx-auto mb-2 text-fantasy-cyan opacity-50 group-hover:opacity-100 transition-opacity" />
                    <div className="text-2xl font-mono font-bold text-white mb-1 truncate">
                      {item.value}
                    </div>
                    <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">
                      {item.label}
                    </div>
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="glass-card p-8 text-center relative overflow-hidden"
              >
                {isBirthday ? (
                  <div className="relative z-10">
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-fantasy-pink mb-4 animate-bounce">
                      HAPPY BIRTHDAY, LEGEND! 🎂
                    </h2>
                    <p className="text-gray-300 italic">
                      "Today, the universe celebrates you. Keep being the main character."
                    </p>
                  </div>
                ) : (
                  <div className="relative z-10">
                    <h2 className="text-xl md:text-2xl font-display font-medium text-fantasy-cyan mb-4">
                      {quote}
                    </h2>
                    <p className="text-gray-500 text-sm uppercase tracking-[0.2em]">
                      Wait for your special day... it's loading.
                    </p>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-r from-fantasy-purple/5 to-fantasy-pink/5" />
              </motion.div>
            </motion.div>
          ) : isFuture ? (
            <motion.div
              key="future"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex flex-col items-center justify-center space-y-8 py-12"
            >
              <div className="relative w-64 h-64 md:w-80 md:h-80">
                <div className="absolute inset-0 portal-swirl rounded-full opacity-40 blur-2xl" />
                <div className="absolute inset-4 portal-swirl rounded-full opacity-60 blur-xl animate-[swirl_15s_linear_infinite_reverse]" />
                <div className="absolute inset-10 portal-swirl rounded-full portal-glow border-4 border-white/20" />
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute inset-0 flex items-center justify-center"
                >
                  <Zap className="w-20 h-20 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.8)]" />
                </motion.div>
              </div>
              
              <div className="text-center space-y-4">
                <h2 className="text-4xl md:text-5xl font-display font-bold text-white tracking-tight">
                  YOU'VE TRAVELED <br />
                  <span className="text-fantasy-cyan">THROUGH TIME!</span>
                </h2>
                <p className="text-gray-400 text-lg max-w-md mx-auto">
                  The portal has opened. You are currently existing in a timeline that hasn't happened yet.
                </p>
                <motion.div
                  animate={{ y: [0, 5, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="inline-block px-6 py-2 rounded-full bg-white/10 border border-white/20 text-fantasy-purple font-bold tracking-widest text-xs uppercase"
                >
                  Temporal Anomaly Detected
                </motion.div>
              </div>
            </motion.div>
          ) : dob && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center p-8 text-gray-500 italic"
            >
              Please enter a valid date to begin your journey.
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Footer */}
      <footer className="absolute bottom-8 left-0 w-full text-center text-gray-600 text-[10px] uppercase tracking-[0.3em] font-bold">
        Fantasy World &copy; {new Date().getFullYear()} • Stay Iconic
      </footer>
    </div>
  );
}